from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.svm import SVC, SVR
import json

# Function to create models based on prediction type
def create_models_from_config(config):
    prediction_type = config["target"]["prediction_type"].lower()

    model_objects = {}
    if "models" not in config:
        raise ValueError("No models specified in the configuration.")

    for model_key, model_config in config["models"].items():
        if not model_config.get("is_selected", False):
            continue  # Skip models not selected

        model_name = model_config["model_name"]
        if prediction_type == "classification" and "regression" in model_name.lower():
            print(f"Skipping {model_name} as it is not suitable for classification.")
            continue
        if prediction_type == "regression" and "classification" in model_name.lower():
            print(f"Skipping {model_name} as it is not suitable for regression.")
            continue

        # Construct the model with specified hyperparameters
        if model_name == "LogisticRegression":
            model_objects[model_key] = LogisticRegression(
                max_iter=model_config.get("max_iter", 100),
                solver='lbfgs'  # Example: Add solver or other necessary parameters
            )
        elif model_name == "RandomForestClassifier":
            model_objects[model_key] = RandomForestClassifier(
                n_estimators=model_config.get("n_estimators", 100),
                max_depth=model_config.get("max_depth", None)
            )
        elif model_name == "LinearRegression":
            model_objects[model_key] = LinearRegression()
        elif model_name == "RandomForestRegressor":
            model_objects[model_key] = RandomForestRegressor(
                n_estimators=model_config.get("n_estimators", 100),
                max_depth=model_config.get("max_depth", None)
            )
        elif model_name == "SVC":
            model_objects[model_key] = SVC(
                C=model_config.get("C", 1.0),
                kernel=model_config.get("kernel", 'rbf')
            )
        elif model_name == "SVR":
            model_objects[model_key] = SVR(
                C=model_config.get("C", 1.0),
                kernel=model_config.get("kernel", 'rbf')
            )
        else:
            print(f"Model {model_name} not implemented.")
    
    return model_objects

# Example JSON Configuration
json_config = {
    "target": {
        "prediction_type": "Regression",
        "target": "petal_width",
        "type": "regression",
        "partitioning": True
    },
    "models": {
        "LogisticRegression": {
            "model_name": "LogisticRegression",
            "is_selected": False,
            "parallelism": 2,
            "min_iter": 30,
            "max_iter": 50,
            "min_regparam": 0.5,
            "max_regparam": 0.8,
            "min_elasticnet": 0.5,
            "max_elasticnet": 0.8
        },
        "RandomForestRegressor": {
            "model_name": "RandomForestRegressor",
            "is_selected": True,
            "n_estimators": 100,
            "max_depth": 10
        },
        "SVR": {
            "model_name": "SVR",
            "is_selected": True,
            "C": 1.0,
            "kernel": "linear"
        }
    }
}

# Example Usage
if __name__ == "__main__":
    models = create_models_from_config(json_config)
    for model_key, model in models.items():
        print(f"Created model: {model_key} -> {model}")
