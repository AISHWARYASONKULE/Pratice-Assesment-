from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.svm import SVC, SVR
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.metrics import mean_squared_error
import numpy as np
import pandas as pd

# Function to create models based on prediction type
def create_models_from_config(config):
    prediction_type = config["target"]["prediction_type"].lower()

    model_objects = {}
    if "models" not in config:
        raise ValueError("No models specified in the configuration.")

    for model_key, model_config in config["models"].items():
        if not model_config.get("is_selected", False):
            continue  # Skip models not selected

        model_name = model_config["model_name"]
        if prediction_type == "classification" and "regression" in model_name.lower():
            print(f"Skipping {model_name} as it is not suitable for classification.")
            continue
        if prediction_type == "regression" and "classification" in model_name.lower():
            print(f"Skipping {model_name} as it is not suitable for regression.")
            continue

        # Construct the model with specified hyperparameters
        if model_name == "LogisticRegression":
            model_objects[model_key] = LogisticRegression(max_iter=model_config.get("max_iter", 100), solver='lbfgs')
        elif model_name == "RandomForestClassifier":
            model_objects[model_key] = RandomForestClassifier(n_estimators=model_config.get("n_estimators", 100), max_depth=model_config.get("max_depth", None))
        elif model_name == "LinearRegression":
            model_objects[model_key] = LinearRegression()
        elif model_name == "RandomForestRegressor":
            model_objects[model_key] = RandomForestRegressor(n_estimators=model_config.get("n_estimators", 100), max_depth=model_config.get("max_depth", None))
        elif model_name == "SVC":
            model_objects[model_key] = SVC(C=model_config.get("C", 1.0), kernel=model_config.get("kernel", 'rbf'))
        elif model_name == "SVR":
            model_objects[model_key] = SVR(C=model_config.get("C", 1.0), kernel=model_config.get("kernel", 'rbf'))
        else:
            print(f"Model {model_name} not implemented.")
    
    return model_objects

# Function to apply grid search for hyperparameter tuning
def apply_grid_search(model, param_grid, X_train, y_train, cv_strategy):
    grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=cv_strategy, n_jobs=-1, verbose=2)
    grid_search.fit(X_train, y_train)
    print(f"Best hyperparameters for {model}: {grid_search.best_params_}")
    return grid_search.best_estimator_

# Function to get Time-based cross-validation strategy
def get_time_based_cv(config, X_train):
    num_folds = config["Time-based K-fold(with overlap)"].get("num_of_folds", 5)
    split_ratio = config["Time-based K-fold(with overlap)"].get("split_ratio", 0.2)
    return TimeSeriesSplit(n_splits=num_folds)

# Updated pipeline execution with hyperparameter tuning and model fitting
def execute_pipeline_with_hyperparameter_tuning(config, data):
    target_name, prediction_type, partitioning, steps = parse_config(config)

    if prediction_type != "regression":
        raise ValueError("Only regression is supported in this pipeline.")

    X = data.drop(columns=[target_name])
    y = data[target_name]

    if partitioning:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    else:
        X_train, X_test, y_train, y_test = X, X, y, y

    # Apply feature handling and reduction if needed
    for step in steps:
        if step["name"] == "feature_handling":
            feature_config = step.get("features", {})
            X_train = handle_missing_values(X_train, feature_config)
            X_test = handle_missing_values(X_test, feature_config)
        elif step["name"] == "feature_reduction":
            feature_reduction_config = step.get("feature_reduction", {})
            X_train = apply_feature_reduction(X_train, y_train, feature_reduction_config)
            X_test = X_test[X_train.columns]  # Keep same features in test data
        elif step["name"] == "model_building":
            hyperparams = step.get("hyperparameters", {})
            models = create_models_from_config(config)

            # Get Time-based cross-validation if specified
            cv_strategy = get_time_based_cv(config, X_train) if hyperparams.get("cross_validation_strategy") == "Time-based K-fold (with overlap)" else 5

            for model_key, model in models.items():
                # Create parameter grid for GridSearchCV based on the hyperparameters in the config
                param_grid = {
                    'C': [0.1, 1, 10],
                    'max_iter': [50, 100, 200],
                    'n_estimators': [50, 100, 150],
                    'max_depth': [None, 10, 20],
                }
                best_model = apply_grid_search(model, param_grid, X_train, y_train, cv_strategy)
                predictions = best_model.predict(X_test)
                mse = mean_squared_error(y_test, predictions)
                print(f"Mean Squared Error for {model_key}: {mse}")

# Example JSON Configuration
json_config = {
    "target": {
        "prediction_type": "Regression",
        "target": "petal_width",
        "type": "regression",
        "partitioning": True
    },
    "models": {
        "RandomForestRegressor": {
            "model_name": "RandomForestRegressor",
            "is_selected": True,
            "n_estimators": 100,
            "max_depth": 10
        },
        "SVR": {
            "model_name": "SVR",
            "is_selected": True,
            "C": 1.0,
            "kernel": "linear"
        }
    },
    "hyperparameters": {
        "search_method": "Grid Search",
        "Grid Search": {
            "is_selected": True,
            "shuffle_grid": True,
            "random_state": 0,
            "max_iterations": 0,
            "max_search_time": 0,
            "cross_validation_strategy": "Time-based K-fold (with overlap)",
            "Time-based K-fold(with overlap)": {
                "is_selected": True,
                "num_of_folds": 3,
                "split_ratio": 0.2,
                "stratified": False
            }
        }
    }
}

# Example Usage
if __name__ == "__main__":
    data = pd.DataFrame({
        "sepal_length": [5.1, 4.9, 4.7, 4.6],
        "sepal_width": [3.5, 3.0, 3.2, 3.1],
        "petal_length": [1.4, 1.4, 1.3, 1.5],
        "petal_width": [0.2, 0.2, 0.2, 0.3]
    })
    
    execute_pipeline_with_hyperparameter_tuning(json_config, data)
