import pandas as pd
import json

# Function to handle missing values
def handle_missing_values(data, feature_config):
    for feature, config in feature_config.items():
        if config["is_selected"] and config["feature_variable_type"] == "numerical":
            missing_handling = config["feature_details"].get("missing_values", "").lower()
            if missing_handling == "impute":
                impute_method = config["feature_details"].get("impute_with", "").lower()
                if impute_method == "average of values":
                    mean_value = data[feature].mean()
                    data[feature].fillna(mean_value, inplace=True)
                elif impute_method == "median":
                    median_value = data[feature].median()
                    data[feature].fillna(median_value, inplace=True)
                elif impute_method == "specific_value":
                    impute_value = config["feature_details"].get("impute_value", 0)
                    data[feature].fillna(impute_value, inplace=True)
                else:
                    raise ValueError(f"Unsupported imputation method: {impute_method}")
    return data

# Updated execute_pipeline to include feature handling
def execute_pipeline_with_feature_handling(config, data):
    target_name, prediction_type, partitioning, steps = parse_config(config)

    if prediction_type != "regression":
        raise ValueError("Only regression is supported in this pipeline.")

    # Partition data if required
    X = data.drop(columns=[target_name])
    y = data[target_name]

    if partitioning:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    else:
        X_train, X_test, y_train, y_test = X, X, y, y

    for step in steps:
        if step["name"] == "feature_handling":
            feature_config = step.get("features", {})
            X_train = handle_missing_values(X_train, feature_config)
            X_test = handle_missing_values(X_test, feature_config)
        elif step["name"] == "feature_generation":
            print("Feature generation logic goes here.")
        elif step["name"] == "model_building":
            hyperparams = step.get("hyperparameters", {})
            model = RandomForestRegressor(random_state=42)
            grid_search = GridSearchCV(model, hyperparams, cv=3, scoring='neg_mean_squared_error')
            grid_search.fit(X_train, y_train)
            print(f"Best hyperparameters: {grid_search.best_params_}")
            best_model = grid_search.best_estimator_
            predictions = best_model.predict(X_test)
            mse = mean_squared_error(y_test, predictions)
            print(f"Mean Squared Error: {mse}")

# Example usage
if __name__ == "__main__":
    json_config = {
        "target": {
            "prediction_type": "Regression",
            "target": "petal_width",
            "type": "regression",
            "partitioning": True
        },
        "steps": [
            {
                "name": "feature_handling",
                "features": {
                    "sepal_length": {
                        "feature_name": "sepal_length",
                        "is_selected": True,
                        "feature_variable_type": "numerical",
                        "feature_details": {
                            "numerical_handling": "Keep as regular numerical feature",
                            "rescaling": "No rescaling",
                            "make_derived_feats": False,
                            "missing_values": "Impute",
                            "impute_with": "Average of values",
                            "impute_value": 0
                        }
                    }
                }
            }
        ]
    }
    
    data = pd.DataFrame({
        "sepal_length": [5.1, 4.9, None, 4.6],
        "sepal_width": [3.5, 3.0, 3.2, 3.1],
        "petal_length": [1.4, 1.4, 1.3, 1.5],
        "petal_width": [0.2, 0.2, 0.2, 0.3]
    })
    
    execute_pipeline_with_feature_handling(json_config, data)
