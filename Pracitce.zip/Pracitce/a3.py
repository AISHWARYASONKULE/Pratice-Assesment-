from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestRegressor
import numpy as np

# Function for feature reduction
def apply_feature_reduction(data, target, feature_reduction_config):
    method = feature_reduction_config.get("feature_reduction_method", "")
    
    if method == "No Reduction":
        print("No feature reduction applied.")
        return data

    elif method == "Correlation with target":
        print("Applying correlation-based feature reduction.")
        correlation = data.corrwith(target).abs()  # Absolute correlation
        num_features = feature_reduction_config["Correlation with target"].get("num_of_features_to_keep", 0)
        top_features = correlation.sort_values(ascending=False).head(num_features).index
        return data[top_features]

    elif method == "Tree-based":
        print("Applying tree-based feature selection.")
        num_features = feature_reduction_config["Tree-based"].get("num_of_features_to_keep", 0)
        model = RandomForestRegressor(n_estimators=100, random_state=42)
        model.fit(data, target)
        feature_importances = model.feature_importances_
        top_indices = np.argsort(feature_importances)[-num_features:]
        return data.iloc[:, top_indices]

    elif method == "Principal Component Analysis":
        print("Applying PCA for dimensionality reduction.")
        num_features = feature_reduction_config["Principal Component Analysis"].get("num_of_features_to_keep", 0)
        pca = PCA(n_components=num_features)
        reduced_data = pca.fit_transform(data)
        return pd.DataFrame(reduced_data, columns=[f"PC{i+1}" for i in range(num_features)])
    
    else:
        raise ValueError(f"Unsupported feature reduction method: {method}")

# Updated pipeline execution with feature reduction
def execute_pipeline_with_feature_reduction(config, data):
    target_name, prediction_type, partitioning, steps = parse_config(config)

    if prediction_type != "regression":
        raise ValueError("Only regression is supported in this pipeline.")

    X = data.drop(columns=[target_name])
    y = data[target_name]

    if partitioning:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    else:
        X_train, X_test, y_train, y_test = X, X, y, y

    for step in steps:
        if step["name"] == "feature_handling":
            feature_config = step.get("features", {})
            X_train = handle_missing_values(X_train, feature_config)
            X_test = handle_missing_values(X_test, feature_config)
        elif step["name"] == "feature_reduction":
            feature_reduction_config = step.get("feature_reduction", {})
            X_train = apply_feature_reduction(X_train, y_train, feature_reduction_config)
            X_test = X_test[X_train.columns]  # Keep same features in test data
        elif step["name"] == "model_building":
            hyperparams = step.get("hyperparameters", {})
            model = RandomForestRegressor(random_state=42)
            grid_search = GridSearchCV(model, hyperparams, cv=3, scoring='neg_mean_squared_error')
            grid_search.fit(X_train, y_train)
            print(f"Best hyperparameters: {grid_search.best_params_}")
            best_model = grid_search.best_estimator_
            predictions = best_model.predict(X_test)
            mse = mean_squared_error(y_test, predictions)
            print(f"Mean Squared Error: {mse}")

# Example usage
if __name__ == "__main__":
    json_config = {
        "target": {
            "prediction_type": "Regression",
            "target": "petal_width",
            "type": "regression",
            "partitioning": True
        },
        "steps": [
            {
                "name": "feature_handling",
                "features": {
                    "sepal_length": {
                        "feature_name": "sepal_length",
                        "is_selected": True,
                        "feature_variable_type": "numerical",
                        "feature_details": {
                            "numerical_handling": "Keep as regular numerical feature",
                            "rescaling": "No rescaling",
                            "make_derived_feats": False,
                            "missing_values": "Impute",
                            "impute_with": "Average of values",
                            "impute_value": 0
                        }
                    }
                }
            },
            {
                "name": "feature_reduction",
                "feature_reduction": {
                    "feature_reduction_method": "Correlation with target",
                    "No Reduction": {
                        "is_selected": False,
                        "num_of_features_to_keep": 0
                    },
                    "Correlation with target": {
                        "is_selected": True,
                        "num_of_features_to_keep": 2
                    },
                    "Tree-based": {
                        "is_selected": False,
                        "num_of_features_to_keep": 0,
                        "depth_of_trees": 0,
                        "num_of_trees": 0
                    },
                    "Principal Component Analysis": {
                        "is_selected": False,
                        "num_of_features_to_keep": 0
                    }
                }
            }
        ]
    }
    
    data = pd.DataFrame({
        "sepal_length": [5.1, 4.9, 4.7, 4.6],
        "sepal_width": [3.5, 3.0, 3.2, 3.1],
        "petal_length": [1.4, 1.4, 1.3, 1.5],
        "petal_width": [0.2, 0.2, 0.2, 0.3]
    })
    
    execute_pipeline_with_feature_reduction(json_config, data)
